# Uma vez...

Página de carta digital, feita em HTML/CSS/JavaScript.

## Publicar gratuitamente com Vercel
1. Crie uma conta em https://vercel.com/
2. Crie um repositório no GitHub e envie o `index.html`.
3. No Vercel, importe o repositório.
4. Publique. O Vercel fornecerá um link público.

## Publicar com GitHub Pages
1. Crie um repositório no GitHub.
2. Envie o `index.html`.
3. Vá em Settings → Pages.
4. Em Source, selecione a branch principal e a pasta `/root`.
5. Salve e aguarde a publicação.

A página foi pensada primeiro para celular.
